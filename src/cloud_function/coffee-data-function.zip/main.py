from google.cloud import storage
import datetime
import json
from flask import escape, jsonify

def process_coffee_data(request):
    # Set CORS headers for preflight requests
    if request.method == 'OPTIONS':
        # Allows GET requests from any origin with the Content-Type
        # header and caches preflight response for an 3600s
        headers = {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'POST',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Max-Age': '3600'
        }
        return ('', 204, headers)

    # Set CORS headers for main requests
    headers = {
        'Access-Control-Allow-Origin': '*'
    }

    request_json = request.get_json()
    if request_json:
        client = storage.Client()
        bucket = client.bucket('coffee-data-c8b0')  # The bucket name is already set here
        blob = bucket.blob(f"{datetime.datetime.now(datetime.timezone.utc).isoformat()}.json")
        blob.upload_from_string(json.dumps(request_json), content_type='application/json')
        return ('Success', 200, headers)  # Include headers in the response
    else:
        return ('Bad Request', 400, headers)  # Include headers in the response as well
